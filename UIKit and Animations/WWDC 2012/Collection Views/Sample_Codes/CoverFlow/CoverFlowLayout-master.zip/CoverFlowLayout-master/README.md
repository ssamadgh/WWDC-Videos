# CoverFlowLayout
模仿 Finder 中的 cover 模式

