/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The main view controller, responsible for creating and positioning all dragging examples.
*/

import UIKit
import MapKit

class ViewController: UIViewController {

    var contentView = UIView()
    var scrollView = UIScrollView()
    var exampleViews = [UIView]()

    var exampleViewsAndDescriptions: [(UIView, String)] {
        var allViewsAndDescriptions = [(UIView, String)]()

        let imagesByStack = [[#imageLiteral(resourceName: "Corkboard_1.jpg"), #imageLiteral(resourceName: "Food_1.jpg")], [#imageLiteral(resourceName: "Fish_1.jpg"), #imageLiteral(resourceName: "Flowers_1.JPG"), #imageLiteral(resourceName: "Flowers_2.jpg")], [#imageLiteral(resourceName: "Flowers_4.jpg"), #imageLiteral(resourceName: "Flowers_5.jpg")], [#imageLiteral(resourceName: "Cooking_1.jpg"), #imageLiteral(resourceName: "Food_4.JPG"), #imageLiteral(resourceName: "Food_5.jpg")]]
        allViewsAndDescriptions.append((PhotoStackColumnView(imagesByStack.map { DraggableStackedPhotosView($0) }), "DraggableStackedPhotosView"))
        allViewsAndDescriptions.append((ImageContainerView(DraggableQRCodeImageView(image: #imageLiteral(resourceName: "qrcode.jpg")), margin: 100), "DraggableQRCodeImageView"))

        let locationImageView = DraggableLocationImageView(#imageLiteral(resourceName: "GGBridge_1.jpg"), location: CLLocation(latitude: 37.8199, longitude: -122.4783))
        allViewsAndDescriptions.append((ImageContainerView(locationImageView, margin: 100), "DraggableLocationImageView"))

        let slowImageViews = [#imageLiteral(resourceName: "Pond_1.jpg"), #imageLiteral(resourceName: "Rainbow_1.JPG"), #imageLiteral(resourceName: "Sand_1.JPG"), #imageLiteral(resourceName: "sunset_1.JPG")].map { ImageContainerView(SlowDraggableImageView($0, delay: 4), margin: 0) }
        allViewsAndDescriptions.append(((PhotoStackColumnView(slowImageViews)), "SlowDraggableImageView"))

        return allViewsAndDescriptions
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        scrollView.addSubview(contentView)
        view.addSubview(scrollView)
        for (exampleView, description) in exampleViewsAndDescriptions {
            exampleView.layer.borderColor = UIColor.lightGray.cgColor
            exampleView.layer.borderWidth = 1

            let label = UILabel()
            label.text = description
            label.font = UIFont.systemFont(ofSize: 24)
            exampleView.addSubview(label)
            label.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                label.centerXAnchor.constraint(equalTo: exampleView.centerXAnchor),
                label.bottomAnchor.constraint(equalTo: exampleView.bottomAnchor, constant: -20)
            ])

            contentView.addSubview(exampleView)
            exampleViews.append(exampleView)
        }

        scrollView.isPagingEnabled = true
    }

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()

        let size = view.bounds.size
        for (index, exampleView) in exampleViews.enumerated() {
            exampleView.frame = CGRect(origin: CGPoint(x: 0, y: CGFloat(index) * size.height), size: size)
        }
        contentView.frame = CGRect(x: 0, y: 0, width: size.width, height: CGFloat(exampleViews.count) * size.height)
        scrollView.frame = CGRect(x: 0, y: 0, width: size.width, height: size.height)
        scrollView.contentSize = contentView.bounds.size
    }
}
