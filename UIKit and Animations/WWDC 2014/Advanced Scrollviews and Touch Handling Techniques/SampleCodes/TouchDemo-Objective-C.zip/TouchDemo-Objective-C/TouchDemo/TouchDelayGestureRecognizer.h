//
//  TouchDelayGestureRecognizer.h
//  TouchDemo
//
//  Created by Antonio081014 on 8/23/15.
//  Copyright (c) 2015 antonio081014.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TouchDelayGestureRecognizer : UIGestureRecognizer

@end
