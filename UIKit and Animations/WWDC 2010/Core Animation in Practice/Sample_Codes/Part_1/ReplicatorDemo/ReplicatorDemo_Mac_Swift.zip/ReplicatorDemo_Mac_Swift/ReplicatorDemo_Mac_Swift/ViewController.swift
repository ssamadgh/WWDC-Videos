//
//  ViewController.swift
//  ReplicatorDemo_Mac_Swift
//
//  Created by Seyed Samad Gholamzadeh on 3/9/18.
//  Copyright © 2018 Seyed Samad Gholamzadeh. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

	override func viewDidLoad() {
		super.viewDidLoad()

		// Do any additional setup after loading the view.
	}

	override var representedObject: Any? {
		didSet {
		// Update the view, if already loaded.
		}
	}


}

