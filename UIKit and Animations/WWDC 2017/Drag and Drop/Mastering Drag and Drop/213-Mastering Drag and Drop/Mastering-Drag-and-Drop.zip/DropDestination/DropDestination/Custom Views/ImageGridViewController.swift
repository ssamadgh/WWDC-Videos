/*
See LICENSE folder for this sample’s licensing information.

Abstract:
ImageGridViewController is a view controller that controls a GridView and its enclosing scroll view.
*/

import UIKit

/**
 Wraps a GridView of a given fixed cell size with a
 scroll view. May be subclassed for additional drop
 interaction functionality -- see
 DroppableImageGridViewController.
 */
class ImageGridViewController: UIViewController {

    var fixedCellSize: CGSize = .zero
    let scrollView = UIScrollView()
    var container: GridView!

    init(_ cellSize: CGSize) {
        super.init(nibName:nil, bundle:nil)
        fixedCellSize = cellSize
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }

    override func loadView() {
        container = GridView(fixedCellSize)
        scrollView.addSubview(container)

        scrollView.translatesAutoresizingMaskIntoConstraints = false
        container.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            container.widthAnchor.constraint(equalTo: scrollView.widthAnchor),
            container.heightAnchor.constraint(greaterThanOrEqualTo: scrollView.widthAnchor)
        ])

        view = scrollView
    }

    /**
     Creates and adds a new image view to the
     container, a GridView, and returns this
     newly created image view.
     */
    func nextView() -> DraggableImageView {
        let newView = DraggableImageView()
        newView.clipsToBounds = true
        newView.contentMode = .scaleAspectFill
        container.addArrangedView(newView)
        scrollView.setNeedsLayout()
        return newView
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        container.invalidateIntrinsicContentSize()
        scrollView.contentSize = container.intrinsicContentSize
    }

    func removeViewsInSet(_ viewsToRemove: Set<UIView>) {
        var indicesToRemove = IndexSet()
        for (index, view) in container.arrangedViews.enumerated() {
            guard let view = view as? UIView else { continue }
            if viewsToRemove.contains(view) {
                indicesToRemove.insert(index)
            }
        }

        if indicesToRemove.isEmpty {
            return
        }

        container.removeArrangedViewsAtIndexes(indicesToRemove)
        scrollView.setNeedsLayout()
    }
}
