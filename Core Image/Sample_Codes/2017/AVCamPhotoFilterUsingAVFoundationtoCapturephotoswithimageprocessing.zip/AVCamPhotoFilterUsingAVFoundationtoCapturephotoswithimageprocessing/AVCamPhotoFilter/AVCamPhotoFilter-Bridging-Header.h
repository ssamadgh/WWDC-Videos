/*
See LICENSE.txt for this sample’s licensing information.

Abstract:
Bridging header for AVCamPhotoFilter.
*/

#import "minMaxFromBuffer.h"
