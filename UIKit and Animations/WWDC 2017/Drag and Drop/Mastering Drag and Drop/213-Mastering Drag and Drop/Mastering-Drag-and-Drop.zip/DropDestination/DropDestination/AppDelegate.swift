/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The AppDelegate of DropDestination.
*/

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
}
