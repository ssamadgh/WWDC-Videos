/*
See LICENSE folder for this sample’s licensing information.

Abstract:
DraggableStackedPhotosView creates drag items from its image views' images when dragged.
*/

import UIKit

/**
 A DraggableStackedPhotosView is a StackedPhotosView that
 supports dragging. When dragging, this view vends a list
 of drag items constructed from each image.
 */
class DraggableStackedPhotosView: StackedPhotosView, UIDragInteractionDelegate {

    override init(_ images: [UIImage]) {
        super.init(images)

        isUserInteractionEnabled = true
        addInteraction(UIDragInteraction(delegate: self))
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    var dragItems: [UIDragItem] {
        return imageViews.map { (imageView) -> UIDragItem in
            let itemProvider = NSItemProvider(object: imageView.image!)
            let item = UIDragItem(itemProvider: itemProvider)
            item.localObject = imageView
            return item
        }
    }

    // MARK: UIDragInteractionDelegate

    func dragInteraction(_ interaction: UIDragInteraction, itemsForBeginning session: UIDragSession) -> [UIDragItem] {
        return dragItems
    }

    func dragInteraction(_ interaction: UIDragInteraction, itemsForAddingTo session: UIDragSession, withTouchAt point: CGPoint) -> [UIDragItem] {
        return dragItems
    }

    func dragInteraction(_ interaction: UIDragInteraction, previewForLifting item: UIDragItem, session: UIDragSession) -> UITargetedDragPreview? {
        guard let imageView = item.localObject as? UIImageView else { return nil }
        return UITargetedDragPreview(view: imageView)
    }
}
