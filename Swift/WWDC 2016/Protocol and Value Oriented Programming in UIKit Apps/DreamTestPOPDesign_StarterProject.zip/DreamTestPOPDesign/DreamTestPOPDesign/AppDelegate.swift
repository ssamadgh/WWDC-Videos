//
//  AppDelegate.swift
//  DreamTestPOPDesign
//
//  Created by Seyed Samad Gholamzadeh on 6/16/1396 AP.
//  Copyright © 1396 AP Seyed Samad Gholamzadeh. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


}

