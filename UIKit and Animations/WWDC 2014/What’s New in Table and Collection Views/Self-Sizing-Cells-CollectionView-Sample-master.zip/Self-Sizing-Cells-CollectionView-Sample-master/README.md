# Self-Sizing-Cells-CollectionView-Sample

Sample project of self sizing collection view cells with labels
