/*
See LICENSE folder for this sample’s licensing information.

Abstract:
ImageContainerView wraps an image view, sizing it appropriately within its bounds.
*/

import UIKit

/**
 An ImageContainerView wraps an image view, sizing it
 appropriately within its bounds, with margins applied
 on all sides. The child image view is centered within
 this container.
 */
class ImageContainerView: UIView {
    init(_ imageView: UIImageView, margin: CGFloat) {
        super.init(frame: .zero)

        addSubview(imageView)

        guard let image = imageView.image else { return }
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.setContentCompressionResistancePriority(UILayoutPriority.defaultHigh, for: .horizontal)
        imageView.setContentCompressionResistancePriority(UILayoutPriority.defaultHigh, for: .vertical)
        NSLayoutConstraint.activate([
            imageView.widthAnchor.constraint(equalTo: imageView.heightAnchor, multiplier: image.aspectRatio),
            imageView.widthAnchor.constraint(lessThanOrEqualTo: widthAnchor, multiplier: 1, constant: -margin),
            imageView.heightAnchor.constraint(lessThanOrEqualTo: heightAnchor, multiplier: 1, constant: -margin),
            imageView.centerXAnchor.constraint(equalTo: centerXAnchor),
            imageView.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
}
