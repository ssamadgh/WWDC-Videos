/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Images dragged from a SlowDraggableImageView load after a given delay.
*/

import MobileCoreServices
import UIKit

/**
 A SlowDraggableImageView is an image view that supports
 dragging and vends its image when dragged. The item
 provider loading is adjusted to artificially take a long
 time to complete.

 Drag items coming from this view can be dropped into the
 drop destination app to demonstrate custom progress UI.
 */
class SlowDraggableImageView: UIImageView, UIDragInteractionDelegate {

    var delay: TimeInterval = 0

    init(_ image: UIImage?, delay: TimeInterval) {
        super.init(image: image)

        self.delay = delay
        isUserInteractionEnabled = true
        addInteraction(UIDragInteraction(delegate: self))
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }

    var dragItems: [UIDragItem] {
        let itemProvider = NSItemProvider()
        itemProvider.registerDataRepresentation(forTypeIdentifier: kUTTypePNG as String, visibility: .all,
                                                loadHandler: { (completionHandler) -> Progress in
            let progress = Progress(totalUnitCount: 100)
            let loadStartDate = Date()
            DispatchQueue.main.async {
                progress.becomeCurrent(withPendingUnitCount: 100)
                _ = Timer.scheduledTimer(withTimeInterval: 0.033, repeats: true, block: { (timer) in
                    progress.completedUnitCount = self.completedUnitCount(loadStartDate: loadStartDate)
                    if progress.completedUnitCount >= 100 {
                        completionHandler(UIImagePNGRepresentation(self.image!), nil)
                        timer.invalidate()
                    }
                })
            }
            return progress
        })
        return [UIDragItem(itemProvider: itemProvider)]
    }

    func completedUnitCount(loadStartDate: Date) -> Int64 {
        return Int64(round(max(0, min(1, Date().timeIntervalSince(loadStartDate) / self.delay)) * 100))
    }

    // MARK: UIDragInteractionDelegate

    func dragInteraction(_ interaction: UIDragInteraction, itemsForBeginning session: UIDragSession) -> [UIDragItem] {
        return dragItems
    }

    func dragInteraction(_ interaction: UIDragInteraction, itemsForAddingTo session: UIDragSession, withTouchAt point: CGPoint) -> [UIDragItem] {
        return dragItems
    }
}
