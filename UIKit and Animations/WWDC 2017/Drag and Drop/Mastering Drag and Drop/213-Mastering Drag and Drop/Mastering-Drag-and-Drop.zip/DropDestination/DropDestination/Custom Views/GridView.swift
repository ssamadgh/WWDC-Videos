/*
See LICENSE folder for this sample’s licensing information.

Abstract:
GridView is responsible for laying out fixed-size UIViews in a grid.
*/

import UIKit

let gridViewMargin: CGFloat = 18

/**
 A GridView is responsible for laying out UIViews
 of a given fixed size in an evenly spaced grid.
 While a collection view is normally better suited
 for these purposes, we subclass a regular UIView
 to demonstrate that UICollectionView-like drag and
 drop support can also be supported in any arbitrary
 type of UIView using drag and drop interactions.
 */
class GridView: UIView {

    var fixedCellSize: CGSize = CGSize(width: 0, height: 0)
    var arrangedViews = NSMutableArray()

    init(_ cellSize: CGSize) {
        super.init(frame: .zero)
        fixedCellSize = cellSize
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }

    var numberOfRows: Int {
        let columns = numberOfColumns
        let numberOfViews = arrangedViews.count
        guard columns > 0 && numberOfViews > 0 else { return 0 }
        return rowForViewAtIndex(arrangedViews.count - 1) + 1
    }

    var numberOfColumns: Int {
        let viewWidth = bounds.width
        let fractionalNumberOfColumns = Double(viewWidth - gridViewMargin) / Double(fixedCellSize.width + gridViewMargin)
        return max(0, Int(floor(fractionalNumberOfColumns)))
    }

    func rowForViewAtIndex(_ index: Int) -> Int {
        guard 0 <= index && index < arrangedViews.count else { return 0 }
        let columns = numberOfColumns
        return columns > 0 ? Int(floor(Double(index) / Double(columns))) : 0
    }

    func columnForViewAtIndex(_ index: Int) -> Int {
        guard 0 <= index && index < arrangedViews.count else { return 0 }
        guard numberOfColumns > 0 else { return 0 }
        return index % numberOfColumns
    }

    func frameForViewAtIndex(_ index: Int) -> CGRect {
        guard 0 <= index && index < arrangedViews.count else { return .zero }
        return CGRect(x: gridViewMargin + CGFloat(columnForViewAtIndex(index)) * (gridViewMargin + fixedCellSize.width),
                      y: gridViewMargin + CGFloat(rowForViewAtIndex(index)) * (gridViewMargin + fixedCellSize.height),
                      width: fixedCellSize.width,
                      height: fixedCellSize.height)
    }

    override func layoutSubviews() {
        for (index, arrangedView) in arrangedViews.enumerated() {
            (arrangedView as? UIView)?.frame = frameForViewAtIndex(index)
        }
        super.layoutSubviews()
    }

    override var intrinsicContentSize: CGSize {
        return CGSize(width: gridViewMargin + (gridViewMargin + fixedCellSize.width) * CGFloat(numberOfColumns),
                      height: gridViewMargin + (gridViewMargin + fixedCellSize.height) * CGFloat(numberOfRows))
    }

    func addArrangedView(_ view: UIView) {
        arrangedViews.add(view)
        view.frame = frameForViewAtIndex(arrangedViews.count - 1)
        addSubview(view)
        invalidateIntrinsicContentSize()
    }

    func removeArrangedViewsAtIndexes(_ indices: IndexSet) {
        for (index, view) in arrangedViews.enumerated() {
            if indices.contains(index) {
                (view as? UIView)?.removeFromSuperview()
            }
        }
        arrangedViews.removeObjects(at: indices)
        invalidateIntrinsicContentSize()
    }
}
