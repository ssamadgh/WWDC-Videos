//
//  AppDelegate.swift
//  PSOperationsAppForTests
//
//  Created by Matt McMurry on 1/11/16.
//  Copyright © 2016 Pluralsight. All rights reserved.
//

import UIKit
import PSOperations

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

}

