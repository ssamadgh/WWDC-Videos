
This test contains parts from Google Toolbox for Mac
(http://code.google.com/p/google-toolbox-for-mac/)

