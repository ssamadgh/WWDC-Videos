/*
See LICENSE folder for this sample’s licensing information.

Abstract:
StackedPhotosView arranges its image views in a stack.
*/

import UIKit

/**
 A StackedPhotosView represents a series of images
 stacked on top of each other. The last image in the
 array will appear at the top of the stack.
 */
class StackedPhotosView: UIView {

    static let offset: CGFloat = 10
    var imageViews = [UIImageView]()

    init(_ images: [UIImage]) {
        super.init(frame: .zero)

        translatesAutoresizingMaskIntoConstraints = false
        let totalStackOffset: CGFloat = CGFloat(images.count - 1) * CGFloat(StackedPhotosView.offset)
        var currentStackOffset: CGFloat = totalStackOffset
        for image in images {
            let imageView = UIImageView(image: image)
            imageViews.append(imageView)
            addSubview(imageView)

            imageView.translatesAutoresizingMaskIntoConstraints = false
            imageView.setContentCompressionResistancePriority(UILayoutPriority.defaultHigh, for: .horizontal)
            imageView.setContentCompressionResistancePriority(UILayoutPriority.defaultHigh, for: .vertical)
            NSLayoutConstraint.activate([
                imageView.widthAnchor.constraint(equalTo: imageView.heightAnchor, multiplier: image.aspectRatio),
                imageView.topAnchor.constraint(equalTo:self.topAnchor, constant:currentStackOffset),
                imageView.leftAnchor.constraint(equalTo:self.leftAnchor, constant:currentStackOffset),
                imageView.widthAnchor.constraint(lessThanOrEqualTo:self.widthAnchor, constant:-totalStackOffset),
                imageView.heightAnchor.constraint(lessThanOrEqualTo:self.heightAnchor, constant:-totalStackOffset)
            ])

            currentStackOffset -= StackedPhotosView.offset
        }
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
}
