/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Miscellaneous utilities used to support draggable view examples.
*/

import CoreGraphics
import ImageIO
import MapKit

typealias MapItemLoadCompletionHandler = (MKMapItem?, Error?) -> Void

extension CLLocation {

    func loadMapItem(_ completionHandler: @escaping MapItemLoadCompletionHandler) {
        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(self, completionHandler: { (placemarks, error) in
            guard let placemarks = placemarks else {
                completionHandler(nil, error)
                return
            }
            guard !placemarks.isEmpty else {
                completionHandler(nil, error)
                return
            }
            let mkPlacemark = MKPlacemark(placemark: placemarks[0])
            completionHandler(MKMapItem(placemark: mkPlacemark), nil)
        })
    }
}

extension CGRect {
    var area: CGFloat {
        return width * height
    }
}

extension UIImage {

    func croppedImageInRect(_ rect: CGRect) -> UIImage? {
        guard let cgImage = self.cgImage else { return nil }
        guard let croppedImage = cgImage.cropping(to: rect) else { return nil }
        return UIImage(cgImage: croppedImage, scale: scale, orientation: imageOrientation)
    }

    func computeQRCodeRectsAndMessages() -> [(CGRect, NSString)] {
        let image = CIImage(image: self)
        let detector = CIDetector(ofType: CIDetectorTypeQRCode, context:CIContext())
        guard let features = detector?.features(in: image!) as? [CIQRCodeFeature] else { return [] }
        var rectsAndMessages = [(CGRect, NSString)]()
        for feature in features {
            guard let message = feature.messageString else { continue }
            // Flip about the x axis to convert from the coordinate space used by CoreGraphics.
            var bounds = feature.bounds
            bounds.origin.y = self.size.height - bounds.maxY
            rectsAndMessages.append((bounds, message as NSString))
        }
        return rectsAndMessages
    }

    var aspectRatio: CGFloat {
        return self.size.width / self.size.height
    }
}

extension UIImageView {

    /**
     Converts a rect in image coordinates to a rect in the
     image view's coordinate space. Does not take clipping
     into account.
     */
    func convertFromImageRect(_ rect: CGRect) -> CGRect {
        guard let image = image else { return .zero }
        let widthScale = bounds.width / image.size.width
        let heightScale = bounds.height / image.size.height
        return CGRect(x: rect.minX * widthScale,
                      y: rect.minY * heightScale,
                      width: rect.width * widthScale,
                      height: rect.height * heightScale)
    }
}
