/*
See LICENSE folder for this sample’s licensing information.

Abstract:
DraggableImageView is a UIImageView that implements basic drag interaction
     and is able to show and hide a ProgressSpinnerView.
*/

import UIKit

/**
 A DraggableImageView is a UIImageView that can be
 dragged, and also fades out when dragged. It is also
 capable of presenting and hiding a progress spinner
 within its view hierarchy, given a Progress.
 */
class DraggableImageView: UIImageView, UIDragInteractionDelegate {

    var progressView: ProgressSpinnerView?

    init() {
        super.init(frame: .zero)

        isUserInteractionEnabled = true
        addInteraction(UIDragInteraction(delegate: self))
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }

    func startShowingProgress(_ progress: Progress) {
        progressView?.removeFromSuperview()
        progressView = ProgressSpinnerView(bounds, progress: progress)
        addSubview(progressView!)
    }

    func stopShowingProgress() {
        progressView?.removeFromSuperview()
        progressView = nil
    }

    var dragItems: [UIDragItem] {
        guard let image = image else { return [] }
        let itemProvider = NSItemProvider(object: image)
        let item = UIDragItem(itemProvider: itemProvider)
        item.localObject = self
        return [item]
    }

    // MARK: UIDragInteractionDelegate

    func dragInteraction(_ interaction: UIDragInteraction, willAnimateLiftWith animator: UIDragAnimating, session: UIDragSession) {
        animator.addAnimations {
            self.alpha = 0.25
        }
    }

    func dragInteraction(_ interaction: UIDragInteraction, item: UIDragItem, willAnimateCancelWith animator: UIDragAnimating) {
        animator.addCompletion { _ in
            self.alpha = 1
        }
    }

    func dragInteraction(_ interaction: UIDragInteraction, session: UIDragSession, didEndWith operation: UIDropOperation) {
        UIView.animate(withDuration:0.5, animations: {
            self.alpha = 1
        })
    }

    func dragInteraction(_ interaction: UIDragInteraction, previewForLifting item: UIDragItem, session: UIDragSession) -> UITargetedDragPreview? {
        let imageView = UIImageView(image: image)
        imageView.frame = frame
        imageView.clipsToBounds = true
        imageView.contentMode = .scaleAspectFill
        let target = UIDragPreviewTarget(container: superview!, center:imageView.center)
        return UITargetedDragPreview(view: imageView, parameters: UIDragPreviewParameters(), target: target)
    }

    func dragInteraction(_ interaction: UIDragInteraction, itemsForBeginning session: UIDragSession) -> [UIDragItem] {
        return dragItems
    }

    func dragInteraction(_ interaction: UIDragInteraction, itemsForAddingTo session: UIDragSession, withTouchAt point: CGPoint) -> [UIDragItem] {
        return dragItems
    }
}
