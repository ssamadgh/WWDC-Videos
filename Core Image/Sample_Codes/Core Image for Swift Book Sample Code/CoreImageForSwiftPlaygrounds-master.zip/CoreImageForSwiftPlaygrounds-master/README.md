# CoreImageForSwiftPlaygrounds

Companion playgrounds for my book, [_Core Image for Swift_](https://itunes.apple.com/de/book/core-image-for-swift/id1073029980?l=en&mt=11)

*Core Image for Swift* is available from: 

* [*Core Image for Swift* from iBooks Store](https://itunes.apple.com/us/book/core-image-for-swift/id1073029980?mt=13)
* [*Core Image For Swift* from Gumroad](https://gumroad.com/l/CoreImageForSwift)
