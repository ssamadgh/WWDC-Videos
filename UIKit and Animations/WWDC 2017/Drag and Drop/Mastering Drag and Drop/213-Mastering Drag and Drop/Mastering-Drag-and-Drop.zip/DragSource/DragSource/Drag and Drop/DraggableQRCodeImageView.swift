/*
See LICENSE folder for this sample’s licensing information.

Abstract:
DraggableQRCodeImageView provides a list of drag items representing QR codes.
*/

import UIKit

/**
 The DraggableQRCodeImageView is a subclass of QRCodeDetectedImageView
 supports for dragging cropped images representing the QR codes that
 appear in the image view.
 */
class DraggableQRCodeImageView: QRCodeDetectedImageView, UIDragInteractionDelegate {

    override init(image: UIImage?) {
        super.init(image: image)

        isUserInteractionEnabled = true
        addInteraction(UIDragInteraction(delegate: self))
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    // MARK: UIDragInteractionDelegate

    func dragInteraction(_ interaction: UIDragInteraction, itemsForBeginning session: UIDragSession) -> [UIDragItem] {
        return qrCodes.map { qrCode in
            let itemProvider = NSItemProvider(object: qrCode.message)
            itemProvider.registerObject(qrCode.croppedImage, visibility: .all)
            let item = UIDragItem(itemProvider: itemProvider)
            item.localObject = qrCode
            return item
        }
    }

    func dragPreviewForItem(_ item: UIDragItem) -> UITargetedDragPreview {
        guard let qrCode = item.localObject as? QRCodeDetectionResult else { return UITargetedDragPreview(view: self) }
        let previewView = UIImageView(image: qrCode.croppedImage)
        previewView.frame = convert(convertFromImageRect(qrCode.rectInOriginalImage), to: window)

        let target = UIDragPreviewTarget(container: window!, center: previewView.center)
        let parameters = UIDragPreviewParameters()
        parameters.visiblePath = UIBezierPath(roundedRect: previewView.bounds, cornerRadius:20)

        return UITargetedDragPreview(view: previewView, parameters: parameters, target: target)
    }

    func dragInteraction(_ interaction: UIDragInteraction, previewForLifting item: UIDragItem, session: UIDragSession) -> UITargetedDragPreview? {
        return dragPreviewForItem(item)
    }

    func dragInteraction(_ interaction: UIDragInteraction, previewForCancelling item: UIDragItem,
                         withDefault defaultPreview: UITargetedDragPreview) -> UITargetedDragPreview? {
        return dragPreviewForItem(item)
    }

    func dragInteraction(_ interaction: UIDragInteraction, willAnimateLiftWith animator: UIDragAnimating, session: UIDragSession) {
        animator.addAnimations {
            self.alpha = 0.5
        }
    }

    func dragInteraction(_ interaction: UIDragInteraction, item: UIDragItem, willAnimateCancelWith animator: UIDragAnimating) {
        animator.addAnimations {
            self.alpha = 1
        }
    }

    func dragInteraction(_ interaction: UIDragInteraction, session: UIDragSession, didEndWith operation: UIDropOperation) {
        alpha = 1
    }
}
