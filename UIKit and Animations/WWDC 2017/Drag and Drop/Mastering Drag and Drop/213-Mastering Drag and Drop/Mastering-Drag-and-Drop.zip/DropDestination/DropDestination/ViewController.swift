/*
See LICENSE folder for this sample’s licensing information.

Abstract:
The main view controller, responsible for creating and laying out the droppable image gallery and delete view.
*/

import UIKit

class ViewController: UIViewController, DeleteViewDelegate {

    let grid = DroppableImageGridViewController(CGSize(width: 200, height: 200))

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        addChildViewController(grid)
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        let gridView = grid.view!
        view.addSubview(gridView)

        let deleteView = DroppableDeleteView(self, labelText: "Drop here to delete photos")
        view.addSubview(deleteView)

        gridView.translatesAutoresizingMaskIntoConstraints = false
        deleteView.translatesAutoresizingMaskIntoConstraints = false

        NSLayoutConstraint.activate([
            gridView.widthAnchor.constraint(equalTo: view.widthAnchor),
            gridView.heightAnchor.constraint(equalTo: view.heightAnchor, constant: -150),
            deleteView.widthAnchor.constraint(equalTo: view.widthAnchor),
            deleteView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            deleteView.heightAnchor.constraint(equalToConstant: 150)
        ])
    }

    // MARK: DroppableDeleteViewDelegate

    func view(_ view: DeleteView, didDeleteViews viewsToDelete: Set<UIView>) {
        UIView.animate(withDuration:0.25, animations: {
            self.grid.removeViewsInSet(viewsToDelete)
            self.view.layoutIfNeeded()
        })
    }
}
