/*
See LICENSE folder for this sample’s licensing information.

Abstract:
LocationImageView is a view that contains both an image and a location, represented by an MKMapItem.
*/

import MapKit
import UIKit

/**
 A LocationImageView is a UIImageView that also contains
 an MKMapItem. Upon initialization with a CLLocation, it
 requests a map item via reverse geocoding.
 */
class LocationImageView: UIImageView {

    var mapItem: MKMapItem?

    init(_ image: UIImage, location: CLLocation) {
        super.init(image: image)

        location.loadMapItem { (item, error) in
            guard error == nil else { return }
            self.mapItem = item
        }
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
}
