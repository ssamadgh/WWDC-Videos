/*
Copyright (C) 2015 Apple Inc. All Rights Reserved.
See LICENSE.txt for this sample’s licensing information

Abstract:
Application delegate that sets up the application.
*/

@import UIKit;

@interface TheElementsAppDelegate : NSObject  <UIApplicationDelegate>


@end
