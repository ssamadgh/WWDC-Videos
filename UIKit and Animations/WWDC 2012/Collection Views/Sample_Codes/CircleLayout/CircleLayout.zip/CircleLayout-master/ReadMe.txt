
### CircleLayout ###

===========================================================================
DESCRIPTION:

Shows how to use a collection view to arrange views on a circle and use custom animations when inserting and removing items.

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.1
- (Mark Pospesel) fixed the animations when inserting/removing items

Version 1.0
- First version.

===========================================================================
Copyright (C) 2012 Apple Inc. All rights reserved.
