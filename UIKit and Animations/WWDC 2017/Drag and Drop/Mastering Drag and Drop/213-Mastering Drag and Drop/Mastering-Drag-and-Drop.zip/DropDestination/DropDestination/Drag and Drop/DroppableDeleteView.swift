/*
See LICENSE folder for this sample’s licensing information.

Abstract:
DroppableDeleteView deletes all views in the local objects of a drop session.
*/

import UIKit

/**
 A DroppableDeleteView is a DeleteView that invokes
 its delegate when a drop occurs on it. All local
 objects that represent views in the list of dropped
 items are to be removed.
 */
class DroppableDeleteView: DeleteView, UIDropInteractionDelegate {

    override init(_ delegate: DeleteViewDelegate?, labelText: String) {
        super.init(delegate, labelText: labelText)

        isUserInteractionEnabled = true
        addInteraction(UIDropInteraction(delegate: self))
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    func localViewsForSession(_ session: UIDropSession) -> Set<UIView> {
        var views = Set<UIView>()
        guard let localDragSession = session.localDragSession else { return views }
        for item in localDragSession.items {
            if let view = item.localObject as? UIView {
                views.insert(view)
            }
        }
        return views
    }

    // MARK: UIDropInteractionDelegate

    func dropInteraction(_ interaction: UIDropInteraction, previewForDropping item: UIDragItem,
                         withDefault defaultPreview: UITargetedDragPreview) -> UITargetedDragPreview? {
        let target = UIDragPreviewTarget(container: self,
                                         center: iconView.center,
                                         transform: CGAffineTransform(scaleX: 0.1, y: 0.1))
        return defaultPreview.retargetedPreview(with: target)
    }

    func dropInteraction(_ interaction: UIDropInteraction, sessionDidUpdate session: UIDropSession) -> UIDropProposal {
        if session.localDragSession == nil {
            return UIDropProposal(operation: .forbidden)
        }
        return UIDropProposal(operation: .move)
    }

    func dropInteraction(_ interaction: UIDropInteraction, performDrop session: UIDropSession) {
        delegate?.view(self, didDeleteViews: localViewsForSession(session))
    }

    func dropInteraction(_ interaction: UIDropInteraction, sessionDidEnter session: UIDropSession) {
        alpha = 1
    }

    func dropInteraction(_ interaction: UIDropInteraction, sessionDidExit session: UIDropSession) {
        alpha = 0.5
    }

    func dropInteraction(_ interaction: UIDropInteraction, sessionDidEnd session: UIDropSession) {
        alpha = 0.5
    }
}
