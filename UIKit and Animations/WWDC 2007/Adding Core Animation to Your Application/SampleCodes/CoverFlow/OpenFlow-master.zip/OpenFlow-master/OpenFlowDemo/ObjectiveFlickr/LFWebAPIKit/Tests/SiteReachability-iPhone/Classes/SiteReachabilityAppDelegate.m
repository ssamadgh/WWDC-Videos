//
//  SiteReachabilityAppDelegate.m
//  SiteReachability
//
//  Created by Lukhnos D. Liu on 6/30/09.
//  Copyright Lithoglyph Inc. 2009. All rights reserved.
//

#import "SiteReachabilityAppDelegate.h"
#import "SiteReachabilityViewController.h"

@implementation SiteReachabilityAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
