This project illustrates various Core Animation and Core Graphics features.
