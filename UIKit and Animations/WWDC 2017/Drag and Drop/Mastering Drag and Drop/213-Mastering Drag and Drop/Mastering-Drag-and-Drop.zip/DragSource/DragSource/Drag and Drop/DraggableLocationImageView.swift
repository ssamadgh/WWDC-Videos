/*
See LICENSE folder for this sample’s licensing information.

Abstract:
DraggableLocationImageView provides a single image item represented by a location and an image.
*/

import MapKit
import UIKit

/**
 A DraggableLocationImageView is a LocationImageView that
 supports dragging. This view vends its map item as well
 as its image when dragging, and customizes its preview
 when beginning a drag session.
 */
class DraggableLocationImageView: LocationImageView, UIDragInteractionDelegate {

    override init(_ image: UIImage, location: CLLocation) {
        super.init(image, location: location)

        isUserInteractionEnabled = true
        addInteraction(UIDragInteraction(delegate: self))
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    // MARK: UIDragInteractionDelegate

    func dragInteraction(_ interaction: UIDragInteraction, itemsForBeginning session: UIDragSession) -> [UIDragItem] {
        guard let mapItem = mapItem else { return [] }
        let itemProvider = NSItemProvider(object: mapItem)
        itemProvider.registerObject(image!, visibility: .all)
        return [UIDragItem(itemProvider: itemProvider)]
    }

    func dragInteraction(_ interaction: UIDragInteraction, sessionWillBegin session: UIDragSession) {
        session.items[0].previewProvider = { () -> UIDragPreview in
            guard let image = self.image else { return UIDragPreview(view: self) }
            guard let mapItem = self.mapItem else { return UIDragPreview(view: self) }
            let previewView = LocationPlatterView(image, item: mapItem)
            let inflatedBounds = previewView.bounds.insetBy(dx: -20, dy: -20)
            let parameters = UIDragPreviewParameters()
            parameters.visiblePath = UIBezierPath(roundedRect: inflatedBounds, cornerRadius: 20)
            return UIDragPreview(view: previewView, parameters: parameters)
        }
    }
}
