/*
See LICENSE folder for this sample’s licensing information.

Abstract:
LocationPlatterView is a fixed-size view representing an image and a location.
*/

import MapKit
import UIKit

/**
 A LocationPlatterView is a view of fixed size
 that is capable of representing a given image
 and location.
 */
class LocationPlatterView: UIView {

    init (_ image: UIImage, item: MKMapItem) {
        super.init(frame: CGRect(x: 0, y: 0, width: 200, height: 180))
        let imageView = UIImageView(image: image)
        let cityNameLabel = UILabel()
        let countryNameLabel = UILabel()

        NSLayoutConstraint.activate([
            imageView.widthAnchor.constraint(equalToConstant: 120),
            imageView.heightAnchor.constraint(equalToConstant: 120)
        ])
        imageView.layer.cornerRadius = 60
        imageView.layer.masksToBounds = true

        cityNameLabel.text = item.placemark.locality
        cityNameLabel.font = UIFont.boldSystemFont(ofSize: 16)
        cityNameLabel.numberOfLines = 1

        countryNameLabel.text = item.placemark.country
        countryNameLabel.font = UIFont.boldSystemFont(ofSize: 14)
        countryNameLabel.numberOfLines = 1

        let container = UIStackView(arrangedSubviews: [imageView, cityNameLabel, countryNameLabel])
        container.alignment = .center
        container.axis = .vertical
        container.clipsToBounds = true
        container.frame = bounds

        addSubview(container)
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
}
