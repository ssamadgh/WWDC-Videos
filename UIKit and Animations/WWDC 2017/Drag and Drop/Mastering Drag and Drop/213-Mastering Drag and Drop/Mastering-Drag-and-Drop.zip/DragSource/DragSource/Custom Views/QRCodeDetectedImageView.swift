/*
See LICENSE folder for this sample’s licensing information.

Abstract:
QRCodeDetectedImageView detects and stores information about QR codes that appear in its image.
*/

import UIKit

struct QRCodeDetectionResult {
    var croppedImage: UIImage
    var rectInOriginalImage: CGRect = .zero
    var message: NSString
}

/**
 A QRCodeDetectedImageView represents an image view that
 contains QR codes. Each QR code is determined by a cropped
 image of the source image, and the rect indicating where in
 the source image the QR code appears.
 */
class QRCodeDetectedImageView: UIImageView {

    var qrCodes: [QRCodeDetectionResult] = []

    override init(image: UIImage?) {
        super.init(image: image)

        guard let image = image else { return }
        for (rect, message) in image.computeQRCodeRectsAndMessages() {
            guard let croppedImage = image.croppedImageInRect(rect) else { continue }
            let result = QRCodeDetectionResult(croppedImage: croppedImage, rectInOriginalImage: rect, message: message)
            qrCodes.append(result)
        }
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
}
