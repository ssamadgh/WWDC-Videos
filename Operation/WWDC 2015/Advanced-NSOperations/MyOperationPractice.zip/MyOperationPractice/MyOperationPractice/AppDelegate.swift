/*
  AppDelegate.swift
  OperationPractice

  Created by Seyed Samad Gholamzadeh on 6/27/1396 AP.
  Copyright © 1396 AP Seyed Samad Gholamzadeh. All rights reserved.
 
    Abstract:
    The app delegate. This, by design, has almost no implementation.
*/

import UIKit
import CoreData

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    //MARK: Properties
    
    var window: UIWindow?

    //MARK: UIApplicationDelegate
    
}


