//
//  ViewController.swift
//  TouchDemo-Swift-Starter
//
//  Created by Seyed Samad Gholamzadeh on 7/21/18.
//  Copyright © 2018 Seyed Samad Gholamzadeh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

	var canvasView: UIView!

	override func viewDidLoad() {
		super.viewDidLoad()

		
		let bounds = self.view.bounds
		
		canvasView = UIView(frame: bounds)
		canvasView.backgroundColor = UIColor.darkGray
		view.addSubview(canvasView)
		
		let device = view.traitCollection.userInterfaceIdiom
		self.addDots(device == .pad ? 25 : 10, toView: canvasView)

		DotView.arrangeDotsRandomlyInView(self.canvasView)
	}
	
	func addDots(_ count: Int, toView view: UIView) {
		for _ in 1...count {
			let dot = DotView()
			view.addSubview(dot)
		}
	}


	override func didReceiveMemoryWarning() {
		super.didReceiveMemoryWarning()
		// Dispose of any resources that can be recreated.
	}


}

