### FunHouse ###

===========================================================================
DESCRIPTION:

This is an Image Unit host that builds automatic UI for all filters and that allows applying stacked effects to images.

===========================================================================
BUILD REQUIREMENTS:

Xcode 5.0 or later, Mac OS X v10.9 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.6 or later

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.1
- Updated for OS X 10.9. Replaced deprecated calls. Removed Static Analyzer warnings. Upgraded nib files to xibs.

Version 1.0
- First version.

===========================================================================
Copyright (C) 2004~2014 Apple Inc. All rights reserved.
