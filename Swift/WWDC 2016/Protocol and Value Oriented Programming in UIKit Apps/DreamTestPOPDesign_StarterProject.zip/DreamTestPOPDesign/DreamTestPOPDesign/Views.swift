//
//  DreamCell.swift
//  DreamTestPOPDesign
//
//  Created by Seyed Samad Gholamzadeh on 6/16/1396 AP.
//  Copyright © 1396 AP Seyed Samad Gholamzadeh. All rights reserved.
//

import UIKit

class DreamCell: UITableViewCell {

    var content: UIView = UIView()
    var firstView: UIView = UIView()
    
    override func layoutSubviews() {
        let decoration = CascadingLayout(contents: [firstView], children: [firstView])
        var composedLayout = DecoratingLayout(content: content, decoration: decoration)
        composedLayout.layout(in: bounds)
    }

}

class DreamDetailView: UIView {
    var content: UIView!
    var decoration: UIView!
    
    override func layoutSubviews() {
//        var decoratingLayout = DecoratingLayout(content: content, decoration: decoration)
//        decoratingLayout.layout(in: bounds)
    }

}
