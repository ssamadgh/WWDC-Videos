# Cover Flow on iOS
## Created by Tuo, 2012

Intriggered by http://blog.csdn.net/miracle_of_thinking/article/details/7274850 also plus with CAReplcatorLayer to make dynamic-reflection, so that you can make reflection to 
any view(UIWebview blabla) rather than just images. 


![Prototype](http://farm8.staticflickr.com/7269/7061136509_65b8ffb918_z.jpg "Optional title")

