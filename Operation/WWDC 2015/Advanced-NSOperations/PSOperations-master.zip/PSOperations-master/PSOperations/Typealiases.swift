//
//  Typealiases.swift
//  PSOperations
//
//  Created by Dev Team on 9/20/16.
//  Copyright © 2016 Pluralsight. All rights reserved.
//

public typealias PSOperation = Operation
public typealias PSOperationQueue = OperationQueue
public typealias PSOperationQueueDelegate = OperationQueueDelegate
public typealias PSBlockOperation = BlockOperation
