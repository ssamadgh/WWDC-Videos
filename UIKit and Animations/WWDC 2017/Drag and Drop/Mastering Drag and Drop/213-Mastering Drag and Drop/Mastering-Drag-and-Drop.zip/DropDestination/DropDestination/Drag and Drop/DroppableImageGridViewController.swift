/*
See LICENSE folder for this sample’s licensing information.

Abstract:
DroppableImageGridViewController adds dropped images as image views to its GridView's hierarchy.
*/

import UIKit

/**
 A DroppableImageGridViewController is a ImageGridViewController
 that supports drop interactions. When one or more items
 containing images are dropped within this view, it will insert
 them as image views to its view hierarchy.
 */
class DroppableImageGridViewController: ImageGridViewController, UIDropInteractionDelegate {

    var itemStates = [ObjectIdentifier: (view: DraggableImageView, progress: Progress)]()

    override init(_ cellSize: CGSize) {
        super.init(cellSize)

        view.isUserInteractionEnabled = true
        view.addInteraction(UIDropInteraction(delegate: self))
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }

    // MARK: UIDropInteractionDelegate

    func dropInteraction(_ interaction: UIDropInteraction, sessionDidUpdate session: UIDropSession) -> UIDropProposal {
        if session.localDragSession == nil && session.canLoadObjects(ofClass: UIImage.self) {
            return UIDropProposal(operation: .copy)
        }
        return UIDropProposal(operation: .cancel)
    }

    func dropInteraction(_ interaction: UIDropInteraction, performDrop session: UIDropSession) {
        session.progressIndicatorStyle = .none
        for item in session.items {
            guard item.itemProvider.canLoadObject(ofClass: UIImage.self) else { continue }
            let photoView = nextView()
            let progress = item.itemProvider.loadObject(ofClass: UIImage.self, completionHandler: { (image, _) in
                DispatchQueue.main.async {
                    photoView.stopShowingProgress()
                    photoView.image = image as? UIImage
                }
            })
            itemStates[ObjectIdentifier(item)] = (view: photoView, progress: progress)
        }
    }

    func dropInteraction(_ interaction: UIDropInteraction, item: UIDragItem, willAnimateDropWith animator: UIDragAnimating) {
        guard let state = itemStates[ObjectIdentifier(item)] else { return }
        guard state.view.image == nil else { return }

        state.view.alpha = 0
        state.view.startShowingProgress(state.progress)
        animator.addCompletion { _ in
            state.view.alpha = 1
        }
    }

    func dropInteraction(_ interaction: UIDropInteraction, concludeDrop session: UIDropSession) {
        itemStates.removeAll()
    }

    func dropInteraction(_ interaction: UIDropInteraction, previewForDropping item: UIDragItem,
                         withDefault defaultPreview: UITargetedDragPreview) -> UITargetedDragPreview? {
        guard let state = itemStates[ObjectIdentifier(item)] else { return nil }
        let previewView = ProgressSpinnerView(state.view.frame, progress: state.progress)
        let target = UIDragPreviewTarget(container: container, center: state.view.center)
        return UITargetedDragPreview(view: previewView, parameters: UIDragPreviewParameters(), target: target)
    }
}
