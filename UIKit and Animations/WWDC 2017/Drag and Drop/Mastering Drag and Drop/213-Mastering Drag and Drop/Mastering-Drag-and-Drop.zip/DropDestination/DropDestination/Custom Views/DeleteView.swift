/*
See LICENSE folder for this sample’s licensing information.

Abstract:
Contains DeleteViewDelegate and DeleteView, responsible for handling deletion of dropped views local to the app.
*/

import UIKit

/**
 A DeleteViewDelegate is used by its DeleteView to
 remove a given set of UIViews when deletion is
 requested via the DeleteView.
 */
protocol DeleteViewDelegate: class {
    func view(_ view: DeleteView, didDeleteViews viewsToDelete: Set<UIView>)
}

/**
 The DeleteView handles UI for showing a deletion area.
 Subclasses are responsible for notifying the delegate
 of deletion.

 Refer to DroppableDeleteView for an example.
 */
class DeleteView: UIView {

    weak var delegate: DeleteViewDelegate?
    var iconView: UIImageView!

    init(_ delegate: DeleteViewDelegate?, labelText: String) {
        super.init(frame: .zero)

        self.delegate = delegate

        let topDivider = UIView()
        addSubview(topDivider)
        topDivider.translatesAutoresizingMaskIntoConstraints = false
        topDivider.backgroundColor = UIColor.red
        NSLayoutConstraint.activate([
            topDivider.topAnchor.constraint(equalTo: self.topAnchor, constant: 1),
            topDivider.widthAnchor.constraint(equalTo: self.widthAnchor),
            topDivider.heightAnchor.constraint(equalToConstant: 1)
        ])

        let trashIconView = UIImageView(image: #imageLiteral(resourceName: "trash.png"))
        addSubview(trashIconView)
        trashIconView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            trashIconView.widthAnchor.constraint(equalToConstant: 64),
            trashIconView.heightAnchor.constraint(equalToConstant: 64),
            trashIconView.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            trashIconView.leftAnchor.constraint(equalTo: self.leftAnchor, constant: 20)
        ])
        trashIconView.layer.minificationFilter = kCAFilterTrilinear
        trashIconView.clipsToBounds = true
        trashIconView.layer.cornerRadius = 32
        iconView = trashIconView

        let labelView = UILabel()
        addSubview(labelView)
        labelView.text = labelText
        labelView.font = UIFont.systemFont(ofSize: 24)
        labelView.textColor = UIColor.red
        labelView.allowsDefaultTighteningForTruncation = true
        labelView.numberOfLines = 1
        labelView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            labelView.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            labelView.leftAnchor.constraint(equalTo: trashIconView.rightAnchor, constant: 12)
        ])

        alpha = 0.5
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
}
