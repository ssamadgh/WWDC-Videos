/*
See LICENSE folder for this sample’s licensing information.

Abstract:
ProgressSpinnerView is a flexible-size view representing a given Progress using a spinner.
*/

import UIKit

/**
 A ProgressSpinnerView observes changes in the
 `fractionCompleted` property of its given progress,
 and updates its spinner UI accordingly.
 */
class ProgressSpinnerView: UIView {

    let arcLayer = CAShapeLayer()
    var progress: Progress!
    let progressLabel = UILabel()

    init(_ frame: CGRect, progress: Progress) {
        super.init(frame: frame)

        self.progress = progress
        progress.addObserver(self, forKeyPath: "fractionCompleted", options: .new, context: nil)

        arcLayer.path = UIBezierPath(arcCenter: CGPoint(x: bounds.midX, y: bounds.midY),
                                     radius: 0.2 * min(bounds.width, bounds.height),
                                     startAngle: -CGFloat(Double.pi / 2),
                                     endAngle: 2 * CGFloat(Double.pi) - CGFloat(Double.pi / 2),
                                     clockwise: true).cgPath
        arcLayer.strokeColor = tintColor.cgColor
        arcLayer.fillColor = UIColor.clear.cgColor
        arcLayer.lineWidth = 5
        arcLayer.strokeStart = 0
        arcLayer.strokeEnd = 0
        arcLayer.position = CGPoint.zero
        layer.addSublayer(arcLayer)
        backgroundColor = UIColor.clear
        layer.borderColor = UIColor.lightGray.cgColor
        layer.borderWidth = 2
        layer.cornerRadius = 10

        progressLabel.text = "0%"
        progressLabel.textAlignment = .center
        progressLabel.frame = bounds
        addSubview(progressLabel)
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }

    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?,
                               context: UnsafeMutableRawPointer?) {
        guard let progress = object as? Progress else { return }
        let updatedFraction = progress.fractionCompleted
        DispatchQueue.main.async {
            self.arcLayer.strokeEnd = CGFloat(updatedFraction)
            self.arcLayer.opacity = Float(1 - updatedFraction)
            self.progressLabel.text = String(format: "%d%%", Int(100 * updatedFraction))
        }
    }

    deinit {
        progress.removeObserver(self, forKeyPath: "fractionCompleted")
    }
}
