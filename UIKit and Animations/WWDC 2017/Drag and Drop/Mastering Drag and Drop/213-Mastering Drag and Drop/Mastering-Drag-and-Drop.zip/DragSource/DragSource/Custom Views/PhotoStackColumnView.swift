/*
See LICENSE folder for this sample’s licensing information.

Abstract:
PhotoStackColumnView arranges a given list of views in a vertical stack.
*/

import UIKit

/**
 A PhotoStackColumnView is a view that is able to arrange
 a given list of views in a vertical stack, applying spacing
 and constraints to each view. This wraps and positions a
 UIStackView. This view's purpose is to help lay out other
 views in the app.
 */
class PhotoStackColumnView: UIView {

    static let minimumMargin: CGFloat = 25
    static let verticalSpacing: CGFloat = 10

    let stackView = UIStackView()

    init(_ views: [UIView]) {
        super.init(frame: .zero)

        stackView.spacing = PhotoStackColumnView.verticalSpacing
        addSubview(stackView)
        let totalMarginAmount = 2 * PhotoStackColumnView.minimumMargin
        for view in views {
            stackView.addArrangedSubview(view)

            view.setContentCompressionResistancePriority(UILayoutPriority.defaultHigh, for: .horizontal)
            view.setContentCompressionResistancePriority(UILayoutPriority.defaultHigh, for: .vertical)

            let heightMultiplier = 1.0 / CGFloat(views.count)
            let heightConstant = -totalMarginAmount - PhotoStackColumnView.verticalSpacing
            NSLayoutConstraint.activate([
                view.widthAnchor.constraint(lessThanOrEqualTo: widthAnchor, multiplier: 1, constant: -totalMarginAmount),
                view.heightAnchor.constraint(lessThanOrEqualTo: heightAnchor, multiplier: heightMultiplier, constant: heightConstant)
            ])
        }

        stackView.alignment = .center
        stackView.axis = .vertical
        stackView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            stackView.centerXAnchor.constraint(equalTo: centerXAnchor),
            stackView.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }

    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
}
