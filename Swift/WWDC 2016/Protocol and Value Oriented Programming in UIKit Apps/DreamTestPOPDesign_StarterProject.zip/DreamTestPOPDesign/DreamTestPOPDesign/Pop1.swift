//
//  Pop1.swift
//  DreamTestPOPDesign
//
//  Created by Seyed Samad Gholamzadeh on 6/16/1396 AP.
//  Copyright © 1396 AP Seyed Samad Gholamzadeh. All rights reserved.
//

import Foundation
import UIKit
import SpriteKit

struct DecoratingLayout<Child: Layout, Decoration: Layout>: Layout  where Child.Content == Decoration.Content {
    var contents: [Child.Content] = []

    typealias Content = Child.Content

    var content: Child
    var decoration: Decoration
    
    init(content: Child, decoration: Decoration) {
        self.content = content
        self.decoration = decoration
    }
    mutating func layout(in rect: CGRect) {
        //Perform Layout...
    }
}

struct CascadingLayout<Child: Layout>: Layout {
    var contents: [Child.Content] = []
    
    typealias Content = Child.Content
    var children: [Child]
    mutating func layout(in rect: CGRect) {
        //...
    }
}

protocol Layout {
//    var boundFrame: CGRect {get set}
    mutating func layout(in rect: CGRect)
    associatedtype Content
    var contents: [Content] {get}
}

extension UIView: Layout {
    var contents: [UIView] {
        return self.subviews
    }

    typealias Content = UIView

    func layout(in rect: CGRect) {
        
    }

   
}
extension SKNode: Layout {
    var contents: [SKNode] {
        return self.children
    }

    typealias Content = SKNode

    func layout(in rect: CGRect) {
        
    }

    
}

