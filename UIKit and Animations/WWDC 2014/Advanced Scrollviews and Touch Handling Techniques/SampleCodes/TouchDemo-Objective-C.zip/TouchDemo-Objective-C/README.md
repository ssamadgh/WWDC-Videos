# TouchDemo
Duplicate of Demo from WWDC2014 Session 235 Advanced Scrollviews and Touch Handling Techniques

After watching WWDC2014 Session 235, there is no demo published from Apple. So I just made one duplicate in **Objective-C**. The **sample written in Swift** could be found [here](https://github.com/tadija/TouchDemo).

