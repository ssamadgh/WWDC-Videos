### CIExposureSample ###

===========================================================================
DESCRIPTION:

The 'Hello World' of Core Image. Opens an image and applies an exposure adjust filter to it using a QuartzGL accelerated view.

===========================================================================
BUILD REQUIREMENTS:

Xcode 4.4 or later, Mac OS X v10.7 or later

===========================================================================
RUNTIME REQUIREMENTS:

Mac OS X v10.7 or later

===========================================================================
CHANGES FROM PREVIOUS VERSIONS:

Version 1.1
- Updated project format for Xcode 4.4.

Version 1.0
- First version.

===========================================================================
Copyright (C) 2009-2012 Apple Inc. All rights reserved.
